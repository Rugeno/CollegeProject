import Borrow
import os
import ListSnap
import dt

'''
In this module the user is asked to enter the borrowers name and if the name is not valid 
the user is asked to rewrite a valid name of the user showing appropriate message. If valid
then the quantity of book is increased in the stock database. In case of delay in returning
a 0.5$ fine is applied per day.
'''
def returnBook():
    name=input("Enter name of borrower: ")
    a="Borrow-"+name+".txt"
    try:
        with open(a,"r") as stock:
            lines=stock.readlines()
            lines=[a.strip("$") for a in lines]
    
        with open(a,"r") as RetTxt:
            data=RetTxt.read()
            print(data)
    except:
        print("The borrower name is incorrect")
        returnBook()
        

    b="Return-"+name+".txt"
    with open(b,"w+")as RetTxt:
        RetTxt.write("                Library Management System \n")
        RetTxt.write("                   Returned By: "+ name+"\n")
        RetTxt.write("    Date: " + dt.getDate()+"    Time:"+ dt.getTime()+"\n\n")
        RetTxt.write("S.N.\t\t\tBookname\t\tCost\n")


    total=0.0
    for i in range(10):
        if ListSnap.bookname[i] in data:
            with open(b,"a") as RetTxt:
                RetTxt.write(str(i+1)+"\t\t"+ListSnap.bookname[i]+"\t\t$"+ListSnap.cost[i]+"\n")
                ListSnap.quantity[i]=int(ListSnap.quantity[i])+1
            total+=float(ListSnap.cost[i])
            
    print("\t\t\t\t\t\t\t"+"$"+str(total))
    print("Is the book return date expired?. Press [Y] for Yes and [N] for No")
    stat=input()
    if(stat.upper()=="Y"):
        print("By how many days was the book returned late?")
        day=int(input())
        fine=0.5*day
        with open(b,"a")as RetTxt:
            RetTxt.write("\t\t\t\tTotal Fine: $"+ str(fine)+"\n")
        total=total+fine
    

    print("Final Total: "+ "$"+str(total))
    with open(b,"a")as RetTxt:
        RetTxt.write("\t\t\t\t\tTotal: $"+ str(total))
        
        
    with open("Stock.txt","w+") as stock:
            for i in range(10):
                stock.write(ListSnap.bookname[i]+","+ListSnap.authorname[i]+","+str(ListSnap.quantity[i])+","+"$"+ListSnap.cost[i]+"\n")
    os.remove("Borrow-"+name+".txt")
