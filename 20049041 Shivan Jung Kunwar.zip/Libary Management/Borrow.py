import dt
import ListSnap

'''

In this module, the user is asked to input their respective names and
a validation check is done. If valid the user is allowed to borrow books
that is displayed by the system. Then the quantity of the book is reduced and 
a Boolean with new contents is returned.
'''

def borrowBook():
    success=False
    while(True):
        firstName=input("Enter the first name of the borrower: ")
        if firstName.isalpha():
            break
        print("please input alphabet from A-Z")
    while(True):
        lastName=input("Enter the last name of the borrower: ")
        if lastName.isalpha():
            break
        print("please input alphabet from A-Z")
            
    t="Borrow-"+firstName+".txt"
    with open(t,"w+") as BorTxt:
        BorTxt.write("               Library Management System  \n")
        BorTxt.write("                   Borrowed By: "+ firstName+" "+lastName+"\n")
        BorTxt.write("    Date: " + dt.getDate()+"    Time:"+ dt.getTime()+"\n\n")
        BorTxt.write("S.N. \t\t Bookname \t      Authorname \n" )
    
    while success==False:
        print("Please select an option below:")
        for i in range(len(ListSnap.bookname)):
            print("Enter", i, "to borrow a book", ListSnap.bookname[i])
    
        try:   
            a=int(input())
            try:
                if(int(ListSnap.quantity[a])>0):
                    print("The Book is available")
                    with open(t,"a") as BorTxt:
                        BorTxt.write("1. \t\t"+ ListSnap.bookname[a]+"\t\t  "+ListSnap.authorname[a]+"\n")

                    ListSnap.quantity[a]=int(ListSnap.quantity[a])-1
                    with open("Stock.txt","w+") as BorTxt:
                        for i in range(10):
                            BorTxt.write(ListSnap.bookname[i]+","+ListSnap.authorname[i]+","+str(ListSnap.quantity[i])+","+"$"+ListSnap.cost[i]+"\n")


                    #Stating ofLoop for borrowing multiple books
                    loop=True
                    count=1
                    while loop==True:
                        choice=str(input("Do you want to borrow more books?. Press [y] for yes and [n] for no."))
                        if(choice.upper()=="Y"):
                            count=count+1
                            print("Please select an option below:")
                            for i in range(len(ListSnap.bookname)):
                                print("Enter", i, "to borrow book", ListSnap.bookname[i])
                            a=int(input())
                            if(int(ListSnap.quantity[a])>0):
                                print("The Book is available")
                                with open(t,"a") as BorTxt:
                                    BorTxt.write(str(count) +". \t\t"+ ListSnap.bookname[a]+"\t\t  "+ListSnap.authorname[a]+"\n")

                                ListSnap.quantity[a]=int(ListSnap.quantity[a])-1
                                with open("Stock.txt","w+") as BorTxt:
                                    for i in range(10):
                                        BorTxt.write(ListSnap.bookname[i]+","+ListSnap.authorname[i]+","+str(ListSnap.quantity[i])+","+"$"+ListSnap.cost[i]+"\n")
                                        success=False
                            else:
                                loop=False
                                break
                        elif (choice.upper()=="N"):
                            print ("Thank you for borrowing books from us. ")
                            print("")
                            loop=False
                            success=True
                        else:
                            print("Please choose as instructed")
                        
                else:
                    print("Book is not available")
                    
            except IndexError:
                print("")
                print("Please choose book acording to their number.")
        except ValueError:
            print("")
            print("Please choose as suggested.")
