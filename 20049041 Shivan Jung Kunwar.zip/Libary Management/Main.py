import Return
import ListSnap
import dt
import Borrow

def start():
    while(True):
        print("        Welcome to the library management system     ")
        print("------------------------------------------------------")
        print("Enter 1. To Display the Available Books")
        print("Enter 2. To Borrow a book")
        print("Enter 3. To return a book")
        print("Enter 4. To exit")
        try:
            UserSelection=int(input("Select your choice from 1-4: "))
            print()
            if(UserSelection==1):
                with open("stock.txt","r") as stock:
                    lines=stock.read()
                    print(lines)
                    print ()
   
            elif(UserSelection==2):
                ListSnap.listSnap()
                Borrow.borrowBook()
            elif(UserSelection==3):
                ListSnap.listSnap()
                Return.returnBook()
            elif(UserSelection==4):
                print("Thank you for being here")
                break
            else:
                print("Please enter a valid number from 1-4")
        except ValueError:
            print("Please input as suggested.")
start()
